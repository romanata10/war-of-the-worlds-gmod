$modelname "wow_tripods/tripod_white.mdl"
$body "body" "tripod_0.smd"
$cdmaterials "models/wow_tripods/"
$surfaceprop "metal"
$sequence "idle" "idle.smd" fps 15 loop
$sequence "walk" "walk.smd" fps 15 loop
$bbox -105 -105 0 105 105 290
$cbox -105 -105 0 105 105 290
